There will be a pop-up window when starting, confirm the authorization. When using this version, you do not need to enter the "Test Internet Connection" page. You can stay on the homepage or any interface.

Supported versions:
- FW 7.00 / 7.01 / 7.02（VTX）
- FW 7.50 / 7.51（VTX）
- FW 7.55（VTX）
- FW 8.00 / 8.01（VTX）
- FW 8.03（VTX）
- FW 8.50 / 8.52（VTX）
- FW 9.00（GoldHEN）
- FW 9.03 / 9.04（VTX）
- FW 9.50 / 9.51（VTX）
- FW 9.60（GoldHEN）
- FW 10.00 / 10.01（GoldHEN）
- FW 10.50（GoldHEN）
- FW 10.70 / 10.71（GoldHEN）
- FW 11.00（GoldHEN）

illustrate:
- .Net2.0、32 or 64bit、Win>=7 

- Just demo, don’t have too high expectations, the current overall success rate is not high. The success rates vary between different versions. Please wait patiently~

- If pppwn.py is updated later, there is no need to update the exe. Directly overwrite "pppwn.py"、 "offsets.py" in the main directory & bin of “PS4_stage_bin_all”folder

Step：
1. Open the "Npcap+Python!" folder and install all（install the latest version of python）
2. Open the "PS4_GoldHEN_all" folder, put the corresponding version of goldhen.bin into the root directory of the exfat format U disk, and insert it into the PS4
3. Connect PS4 and PC using a network cable, enter PS4 Settings-Network-Set Internet Connection-Use Lan-Customize-PPPOE, and fill in a name and password.
4. Run "PPPwnGo.exe", select the PS4 version and the corresponding network card, generally the default is fine (unless you have multiple network cards), click the "Go" button
5. Click to enter "Test Internet" in the PS4 network
6. When the execution is completed, "done" will be displayed, and "PPPwn" will pop up in the upper left corner of PS4. If it is stuck, fails, crashes or loses power, repeat 4&5，if it fails more than 3 times in a row, please  turn the PS4 network switch back on or restart PS4

Tip: A little trick that can improve the success rate. After failure, first turn off the network switch of PS4 or disconnect the network cable, then turn it on and try again！

Special thanks Andy for his efforts!



----------------------------------------------------------------------------------------
启动会有一个弹窗，确定给授权，这个版本折腾的时候不需要进入“测试互联网连接”页面，停在首页或者任何界面都可以

默认为C++版，无需安装python环境，只需提前安装好npcap

支持的版本：
- FW 7.00 / 7.01 / 7.02
- FW 7.50 / 7.51
- FW 7.55（VTX）
- FW 8.00 / 8.01
- FW 8.03（VTX）
- FW 8.50 / 8.52（VTX）
- FW 9.00（GoldHEN）
- FW 9.03 / 9.04（VTX）
- FW 9.50（VTX）/ 9.51
- FW 9.60（GoldHEN）
- FW 10.00 / 10.01（GoldHEN）
- FW 10.50（VTX）
- FW 10.70 / 10.71（VTX）
- FW 11.00（GoldHEN）

说明：
- .Net2.0、32或64位、Win>=7 
- 不要有过高期待，当前整体成功率并不高，不同版本之间成功率有差异，耐心等待~
- 如果后续pppwn.py和stage.bin有更新，无需更新exe，直接覆盖根目录的“pppwn.py”、“offsets.py”和“PS4_stage_bin_all”中的bin

简要步骤：
1. 打开“Python!”文件夹，安装里面的内容，建议安装最新版的python
2. 打开“PS4_GoldHEN_all”文件夹，把对应版本的goldhen.bin放入exfat格式的U盘根目录，插入PS4
3. 把PS4和PC使用网线连接，进入PS4设置-网络-设定互联网连接-使用Lan-定制-PPPOE，随便填写一个名称和密码，后面几项默认
4. 运行“PPPwnGo.exe”，选择PS4版本和相应的网卡，一般默认就可以（除非你有多个网卡），点击“Go”按钮
5. 在PS4网络中点击进入“测试互联网”
6. 等待执行结束会显示“done”，PS4左上角会弹出“PPPwned”，如果卡住、失败、死机或断电，重复4&5，连续超过3次失败，请重新打开PS4网络开关或重启PS4

提示：一个可以提高成功率的小技巧，失败后先关闭PS4的网络开关或者断开网线，然后开启后再试！


再次特别感谢阮·Andy的付出！
