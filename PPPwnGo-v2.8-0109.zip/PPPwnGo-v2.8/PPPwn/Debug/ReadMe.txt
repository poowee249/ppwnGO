Debug is only applicable to experienced gamers！
If using it for the first time, do not modify ini！

PPPwn_cpp：
https://github.com/xfangfang/PPPwn_cpp
https://nightly.link/xfangfang/PPPwn_cpp/workflows/ci.yaml/main?status=completed

PPPwn_go：
https://github.com/wetor/PPPwn_go

Collection Table：
https://docs.google.com/spreadsheets/d/1C8zo9YIl6pCx1B_k_7tt_spTWc-Glfs3UdV4WcubPdc/edit#gid=0

