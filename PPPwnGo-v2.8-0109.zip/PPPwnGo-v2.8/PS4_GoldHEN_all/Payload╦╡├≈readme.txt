运行之前，把对应版本的goldhen.bin或payload.bin(vtx)放入exfat格式的U盘根目录，插入PS4
----------------------------------
Before running, put goldhen.bin or payload.bin(vtx) into the root directory of the exfat USB and insert it into PS4